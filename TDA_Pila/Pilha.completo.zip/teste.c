#include "Pilha_interface.h"
#include <stdio.h>

int main(){
  pilha_t* pilha = Init();

  char elemento1 = '!';
  Push(pilha, &elemento1);
  printf("Tamanho pilha: %i\n", Size(pilha));
  char elemento2 = '2';
  Push(pilha, &elemento2);
  char elemento3 = 'o';
  Push(pilha, &elemento3);
  printf("Tamanho pilha: %i\n", Size(pilha));
  char elemento4 = 'g';
  Push(pilha, &elemento4);
  char elemento5 = 'l';
  Push(pilha, &elemento5);
  printf("Tamanho pilha: %i\n", Size(pilha));
  char elemento6 = 'A';
  Push(pilha, &elemento6);


  printf("%c\n", *(char*)Top(pilha));
  Pop(pilha);
  printf("Tamanho pilha: %i\n", Size(pilha));
  printf("%c\n", *(char*)Top(pilha));
  Pop(pilha);
  printf("Tamanho pilha: %i\n", Size(pilha));
  printf("%c\n", *(char*)Top(pilha));
  Pop(pilha);
  printf("Tamanho pilha: %i\n", Size(pilha));
  printf("%c\n", *(char*)Top(pilha));
  Pop(pilha);
  printf("Tamanho pilha: %i\n", Size(pilha));
  printf("%c\n", *(char*)Top(pilha));
  Pop(pilha);
  printf("Tamanho pilha: %i\n", Size(pilha));
  printf("%c\n", *(char*)Top(pilha));
  Pop(pilha);
  printf("Tamanho pilha: %i\n", Size(pilha));

  Destroy(pilha);
  return 0;
}