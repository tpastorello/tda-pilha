#ifndef PILHAPRIVADO_H
#define PILHAPRIVADO_H 
#include "pilhaPublico.h"

int isEmpty(pilha* p);

int isFull(pilha* p);
 
#endif // PILHAPRIVADO_H
